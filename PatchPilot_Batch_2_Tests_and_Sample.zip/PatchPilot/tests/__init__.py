"""PatchPilot test suite."""
