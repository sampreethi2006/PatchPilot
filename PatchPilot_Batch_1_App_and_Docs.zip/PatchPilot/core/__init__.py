"""PatchPilot core package."""
